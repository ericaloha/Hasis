#include <chrono>
#include <iostream>
#include <fstream>
#include <random>
#include <string.h>
// for async IO
#include <algorithm>
#include <thread>
// for ycsb
#include <limits.h>
#include <math.h>
#include <unistd.h>
#include "bplus_tree.h"

// extern off_t global_lsn;
//+++++++++++++++++++++YCSB Generator+++++++++++++++++++++++++++++++++++++++++++++++++
int afterLoad[64] = {0};
int aftertest[64] = {0};
extern off_t malloc_cnt[30];
extern off_t free_cnt[30];
int testphase[64][50] = {0};
extern int kMaxPages;


//==============================HTAP Begin======================================================================

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// global variance
std::map<int, std::vector<std::string> *> *warehouse; // key:value list //0
BPlusItemTree *ItemTree;                              // 1
BPlusStockTree *StockTree;                            // 2
BPlusDistrictTree *DistrictTree;                              // 3
BPlusHistoryfk1Tree *Historyfk1Tree;                         // 4
BPlusHistoryfk2Tree *Historyfk2Tree;                         // 5
BPlusCustomerTree *CustomerTree;                              // 6
BPlusNewOrdersTree *NewOrdersTree;                              // 7
BPlusOrdersTree *OrdersTree;                                // 8
BPlusOrderlineTree *OrderLineTree;                             // 9

std::thread BackGround_ItemTree;
std::thread BackGround_StockTree;
std::thread BackGround_DistrictTree;
std::thread BackGround_History_fk_1_Tree;
std::thread BackGround_History_fk_2_Tree;
std::thread BackGround_CustomerTree;
std::thread BackGround_NewOrderTree;
std::thread BackGround_OrdersTree;
std::thread BackGround_OrderLineTree;
int bg_id = 0;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// fuction tools

// 1. split string
std::vector<std::string> split(std::string s, std::string delimiter)
{
  size_t pos_start = 0, pos_end, delim_len = delimiter.length();
  std::string token;
  std::vector<std::string> res;

  while ((pos_end = s.find(delimiter, pos_start)) != std::string::npos)
  {
    token = s.substr(pos_start, pos_end - pos_start);
    pos_start = pos_end + delim_len;
    if (token == "")
    {
      continue;
    }
    res.push_back(token);
  }
  if (s.substr(pos_start) != "")
    res.push_back(s.substr(pos_start));
  return res;
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// benchmark & warmup



// multithread model

class ProAndCon {
  private:
    std::deque<char*> m_queue;
    std::mutex m_mutex;//全局互斥锁
    std::condition_variable_any m_notEmpty;//全局条件变量（不为空）
    std::condition_variable_any m_notFull;//全局条件变量（不为满）
    int m_maxSize;//队列最大容量

  private:
    //队列为空
    bool isEmpty() const {
        return m_queue.empty();
    }
    //队列已满
    bool isFull() const {
        return m_queue.size() == m_maxSize;
    }

public:
    ProAndCon(int maxSize) {
        this->m_maxSize = maxSize;
    }

    ~ProAndCon();

    void product(char* cmd) {
      
        std::unique_lock<std::mutex> locker(m_mutex);
        while(isFull()) {
            //cout<<"队列已满，请等待"<<endl;
            //生产者等待"产品队列缓冲区不为满"这一条件发生.
            m_notFull.wait(m_mutex);
        }
        //往队列里面生产一个元素,同时通知不为空这个信号量
        m_queue.push_back(cmd);
        m_notEmpty.notify_one();
    }
    char* consumption() {
        std::unique_lock<std::mutex> locker(m_mutex);
        while(isEmpty()) {
           // cout<<"队列已空，请等待"<<endl;
            // 消费者等待"产品队列缓冲区不为空"这一条件发生.
            m_notEmpty.wait(m_mutex);
        }
        //在队列里面消费一个元素,同时通知队列不满这个信号量
        char* v = m_queue.front();
        m_queue.pop_front();
        m_notFull.notify_one();
        return v;
    }
};
void Consumer_StockTree(ProAndCon* itemQ_){
  //INSERT INTO stock values(
  //          2567,1,76,'u43OyncoVY9HLUbSyOnziusa','BAvu1Lo5MB37npdLxuePU6Nq',
  //          'LZkD7IOHDHGW5LtEMy1AbM5U','Uw5pmuAJeMQvkf61td5EUJZS','h2fkUcEQh1AZCUEYs9GWDGPq',
  //          'cIc9jvqjZaDBmbqnlPxDbT4i','awyzkHZ1riklYRI6eTsDHeye','AE5EwnoqjlZ0Lap3IaajsgLJ','YY9UDieRlsLYeAFOhFjH5kXd',
  //          'EWzZpU7OdbZLEy74HdhRt586',0,0,0,'N9Ysnt6Jqf6KkSxK1GWzLaHxHg')
  //std::cout << "+++++++++++++++ TEST Stock Tree BEGIN ++++++++++++++++++++\n";
  std::string StockDir = "/media/hkc/csd_3/HTAP_DirTrees/test";
  std::string DB_path = StockDir + "Stock/";
  std::string db = DB_path + "testStock.db";
  std::string log = DB_path + "testStock.log";
  std::string chpt = DB_path + "chptStock.log";
  StockTree = new BPlusStockTree(db.c_str(), log.c_str(), chpt.c_str(), bg_id++, true);
  // load
  StockTree->SetBaseline();
  StockTree->SetLoadFlag(1);
  char k[32] = {'\0'};
  char v[16 + 240 + 8 + 16 + 16 + 50] = {'\0'};
    while(1){
    
      char* cmd_char = itemQ_->consumption();
      std::string cmd(cmd_char, cmd_char + strlen(cmd_char));
      free(cmd_char);
      if(cmd.find("INSERT")!=cmd.npos){
        std::string contents = cmd.substr(cmd.find("(") + 1, cmd.find(")") - 2);
        contents = contents.replace(contents.find(")"), 1, "");
        replace(contents.begin(), contents.end(), '\'', ',');
        std::vector<std::string> res = split(contents, ",");
        int pk = atoi(res[0].c_str());
        int sk = atoi(res[1].c_str());
        snprintf(k, 32, "%16d%16d", sk,pk);
        snprintf(v, 16 + 24 + 24+ 24+ 24+ 24+ 24+ 24+ 24+ 24+ 24 + 8 + 16 + 16 + 50, "%16s%24s%24s%24s%24s%24s%24s%24s%24s%24s%24s%8s%16s%16s%50s", 
          res[2].c_str(), 
          res[3].c_str(), 
          res[4].c_str(), 
          res[5].c_str(),
          res[6].c_str(),
          res[7].c_str(),
          res[8].c_str(), 
          res[9].c_str(), 
          res[10].c_str(), 
          res[11].c_str(),
          res[12].c_str(),
          res[13].c_str(),
          res[14].c_str(),
          res[15].c_str(),
          res[16].c_str()
          );
        off_t lsn = StockTree->GetLSN();
        StockTree->Put(k, v, lsn);
        StockTree->IncreLSN();
      }else if (cmd.find("SELECT")!=cmd.npos){
        if(cmd.find("s_w_id") < cmd.find("s_i_id")){
          //SELECT count(*) FROM stock WHERE s_w_id = 1 AND s_i_id = 16387 AND s_quantity < 17
          std::string contents = cmd.substr(cmd.find("s_w_id =") + 1, cmd.find("AND s_quantity") - 2);
          std::vector<std::string> res = split(contents, " ");
          int pk = atoi(res[2].c_str());
          int sk = atoi(res[6].c_str());
          snprintf(k, 32, "%16d%16d", sk,pk);
          std::string value;
          StockTree->Get(k, value);
          value[0]=value[1];
        }else{
          std::string contents = cmd.substr(cmd.find("s_i_id =") + 1, cmd.find("AND s_quantity") - 2);
          std::vector<std::string> res = split(contents, " ");
          int pk = atoi(res[6].c_str());
          int sk = atoi(res[2].c_str());
          snprintf(k, 32, "%16d%16d", sk,pk);
          std::string value;
          StockTree->Get(k, value);
          value[0]=value[1];
        }

      }else if (cmd.find("UPDATE")!=cmd.npos){
        //"UPDATE stock SET s_quantity = 86 WHERE s_i_id = 61704 AND s_w_id = 1"
        continue; //pend-hkc-7
      }



      
    }
    return;


}

void Consumer_OrdersTree(ProAndCon* itemQ_){
  // Schema  
    //  create table orders (
    //  o_id int not null,
    //  o_d_id tinyint not null,
    //  o_w_id smallint not null,
    //  o_c_id int, 16
    //  o_entry_d datetime, 20
    //  o_carrier_id tinyint, 16
    //  o_ol_cnt tinyint, 16
    //  o_all_local tinyint, 16
    //  PRIMARY KEY(o_w_id, o_d_id, o_id) ) Engine=InnoDB

    //INSERT INTO orders values(
    //  2999,
    //  10,
    //  2,
    //  2203,
    //  '2023-02-26 21:56:14',
    //  NULL,
    //  12,
    //   1
    //)


  //std::cout << "+++++++++++++++ TEST Orders Tree BEGIN ++++++++++++++++++++\n";
  std::string OrdersDir = "/media/hkc/csd_3/HTAP_DirTrees/test";
  std::string DB_path = OrdersDir + "Orders/";
  std::string db = DB_path + "testOrders.db";
  std::string log = DB_path + "testOrders.log";
  std::string chpt = DB_path + "chptOrders.log";
  OrdersTree = new BPlusOrdersTree(db.c_str(), log.c_str(), chpt.c_str(), bg_id++, true);
  // load
  OrdersTree->SetBaseline();
  OrdersTree->SetLoadFlag(1);
  char k[48] = {'\0'};
  char v[16 + 20 + 16 + 16 +16] = {'\0'};
  while(1){
    char* cmd_char = itemQ_->consumption();
    std::string cmd(cmd_char, cmd_char + strlen(cmd_char));
    free(cmd_char);
    if(cmd.find("INSERT")!=cmd.npos){
      std::string contents = cmd.substr(cmd.find("(") + 1, cmd.find(")") - 2);
      contents = contents.replace(contents.find(")"), 1, "");
      replace(contents.begin(), contents.end(), '\'', ',');
      std::vector<std::string> res = split(contents, ",");
      int pk1 = atoi(res[2].c_str());
      int pk2 = atoi(res[1].c_str());
      int pk3 = atoi(res[0].c_str());
      snprintf(k, 48, "%16d%16d%16d", pk1,pk2,pk3);
      //snprintf(v, 16 + 20 + 16 + 16 +16, "%16s%20s%16s%16s%16s", i, rand() % 10000000, rand() % 10000000, rand() % 10000, rand() % 100000000,rand()%10000000);
      off_t lsn = OrdersTree->GetLSN();
      snprintf(v, 16 + 20 + 16 + 16 +16, "%16s%20s%16s%16s%16s", 
          res[3].c_str(), 
          res[4].c_str(), 
          res[5].c_str(), 
          res[6].c_str(),
          res[7].c_str()
          );
      OrdersTree->Put(k, v, lsn);
      OrdersTree->IncreLSN();
    }else if(cmd.find("SELECT")!=cmd.npos){
      // SELECT o_id, o_entry_d, COALESCE(o_carrier_id,0) FROM orders 
      // WHERE o_w_id = 2 AND o_d_id = 6 AND o_c_id = 13 AND o_id = (SELECT MAX(o_id) FROM orders WHERE o_"...
      //continue;
      
      //0406-hkc pending now!!!
      cmd = cmd.substr(cmd.find("WHERE"),cmd.length());
      std::string contents = cmd.substr(cmd.find("o_w_id") + 1, cmd.length() - 2);
      //replace(contents.begin(), contents.end(), '\'', ',');
      std::vector<std::string> res = split(contents, " ");
      int pk1 = atoi(res[2].c_str());

      std::string contents1 = cmd.substr(cmd.find("o_d_id") + 1, cmd.length() - 2);
      //replace(contents.begin(), contents.end(), '\'', ',');
      std::vector<std::string> res1 = split(contents1, " ");

      int pk2 = atoi(res1[2].c_str());
      std::string contents2 = cmd.substr(cmd.find("o_id") + 1, cmd.length() - 2);
      //replace(contents.begin(), contents.end(), '\'', ',');
      std::vector<std::string> res2 = split(contents2, " ");

      int pk3 = atoi(res2[2].c_str());      //pend-hkc-2
      //need further expansion, here are only for test case
      snprintf(k, 48, "%16d%16d%16d", pk1,pk2,pk3);
    }else if(cmd.find("UPDATE")!=cmd.npos){ //UPDATE orders SET o_carrier_id = 10 WHERE o_id = 2667 AND o_d_id = 1 AND o_w_id = 1"
      continue; //pend-hkc-4
    }

  }
  return;

}

void Consumer_ItemTree(ProAndCon* itemQ_){
// 2023-02-26T13:56:04.057992Z	    3 Query	create table item (
  // i_id int not null,
  // i_im_id int,
  // i_name varchar(24),
  // i_price decimal(5,2),
  // i_data varchar(50),
  // PRIMARY KEY(i_id) ) Engine=InnoDB


    // init a btree
    std::string ItemDir = "/media/hkc/csd_3/HTAP_DirTrees/test";
    std::string DB_path = ItemDir + "Item/";
    std::string db = DB_path + "testItem.db";
    std::string log = DB_path + "testItem.log";
    std::string chpt = DB_path + "chptItem.log";
    ItemTree = new BPlusItemTree(db.c_str(), log.c_str(), chpt.c_str(), bg_id++, true);

    // INSERT INTO item values(
    //   1,2498,'8TA69fNTQqhRD7KLKkV',77.2699966430664,
    //   '87LD1FH6AFFbPLl2hCSXsukzC3IxW23eAOqBb7')
    //
    ItemTree->SetBaseline();
    ItemTree->SetLoadFlag(1);
    char k[16] = {'\0'};
    char v[16 + 24 + 8 + 50] = {'\0'};
    while(1){
      //SELECT i_price, i_name, i_data FROM item WHERE i_id = 45702

      char* cmd_char = itemQ_->consumption();
      std::string cmd(cmd_char, cmd_char + strlen(cmd_char));
      free(cmd_char);
      if(cmd.find("INSERT")!=cmd.npos){
        std::string contents = cmd.substr(cmd.find("(") + 1, cmd.find(")") - 2);
        contents = contents.replace(contents.find(")"), 1, "");
        replace(contents.begin(), contents.end(), '\'', ',');
        std::vector<std::string> res = split(contents, ",");

        int pk = atoi(res[0].c_str());
        snprintf(k, 16, "%16d", pk);
        snprintf(v, 16 + 24 + 8 + 50, "%16s%24s%8s%50s", 
          res[1].c_str(), 
          res[2].c_str(), 
          res[3].c_str(), 
          res[4].c_str()
          );
        off_t lsn = ItemTree->GetLSN();
        ItemTree->Put(k, v, lsn);
        ItemTree->IncreLSN();
      }else if(cmd.find("SELECT")!=cmd.npos){
        //SELECT i_price, i_name, i_data FROM item WHERE i_id = 45702
        std::string contents = cmd.substr(cmd.find("i_id = ") + 1, cmd.length() - 2);
        int pk = atoi(contents.c_str());
        snprintf(k, 16, "%16d", pk);
        std::string value;
        ItemTree->Get(k,value);
        value[0]= value[1];

      }else if(cmd.find("UPDATE")!=cmd.npos){
      continue;
    }
      
    }
    return;
}


void Consumer_DistrictTree(ProAndCon* itemQ_){
  // Schema  
  /*
  create table district (
  d_id tinyint not null, 
  d_w_id smallint not null, 

  d_name varchar(10), 
  d_street_1 varchar(20), 
  d_street_2 varchar(20), 
  d_city varchar(20), 
  d_state char(2), 
  d_zip char(9), 
  d_tax decimal(4,2), 
  d_ytd decimal(12,2), 
  d_next_o_id int,
  primary key (d_w_id, d_id) ) Engine=InnoDB
  */


  //std::cout << "+++++++++++++++ TEST District Tree BEGIN ++++++++++++++++++++\n";
  std::string DistrictDir = "/media/hkc/csd_3/HTAP_DirTrees/test";
  std::string DB_path = DistrictDir + "District/";
  std::string db = DB_path + "testDistrict.db";
  std::string log = DB_path + "testDistrict.log";
  std::string chpt = DB_path + "chptDistrict.log";
  DistrictTree = new BPlusDistrictTree(db.c_str(), log.c_str(), chpt.c_str(), bg_id++, true);
  // load
  DistrictTree->SetBaseline();
  DistrictTree->SetLoadFlag(1);
  char k[32] = {'\0'};
  char v[10+20+20+20+2+9+6+14+16] = {'\0'};
  while(1){
    char* cmd_char = itemQ_->consumption();
    std::string cmd(cmd_char, cmd_char + strlen(cmd_char));
    free(cmd_char);
    if(cmd.find("INSERT")!=cmd.npos){
      std::string contents = cmd.substr(cmd.find("(") + 1, cmd.find(")") - 2);
      contents = contents.replace(contents.find(")"), 1, "");
      replace(contents.begin(), contents.end(), '\'', ',');
      std::vector<std::string> res = split(contents, ",");
      int pk1 = atoi(res[1].c_str());
      int pk2 = atoi(res[0].c_str());
      snprintf(k, 32, "%16d%16d", pk1,pk2);
      //snprintf(v, 16 + 20 + 16 + 16 +16, "%16s%20s%16s%16s%16s", i, rand() % 10000000, rand() % 10000000, rand() % 10000, rand() % 100000000,rand()%10000000);
      off_t lsn = DistrictTree->GetLSN();
      snprintf(v, 10+20+20+20+2+9+6+14+16, "%10s%20s%20s%20s%2s%9s%6s%14s%16s", 
          res[2].c_str(), 
          res[3].c_str(), 
          res[4].c_str(), 
          res[5].c_str(), 
          res[6].c_str(),
          res[7].c_str(),
          res[8].c_str(),
          res[9].c_str(),
          res[10].c_str()
          );
      DistrictTree->Put(k, v, lsn);
      DistrictTree->IncreLSN();

    }else if (cmd.find("SELECT")!=cmd.npos){
      //SELECT d_next_o_id, d_tax FROM district WHERE d_id = 7 AND d_w_id = 2 FOR UPDATE"
      std::string contents;
      if(cmd.find("d_id") < cmd.find("d_w_id")){
        contents = cmd.substr(cmd.find("d_id =") + 1, cmd.length() - 2);
      }else{
        contents = cmd.substr(cmd.find("d_w_id =") + 1, cmd.length() - 2);
      }
      
      if (contents.find("FOR UPDATE")!=cmd.npos){
        contents = contents.substr(0,contents.find("FOR UPDATE"));
        
      }
      std::vector<std::string> res = split(contents, " ");
      int pk1=0;
      int pk2=0;
      if(cmd.find("d_id") < cmd.find("d_w_id")){
        pk1 = atoi(res[6].c_str());
        pk2 = atoi(res[2].c_str());
      }else{
        pk1 = atoi(res[2].c_str());
        pk2 = atoi(res[6].c_str());
      }
      
      snprintf(k, 32, "%16d%16d", pk1,pk2);
      std::string value;
      DistrictTree->Get(k,value);
      value[0]=value[1];

    }else if (cmd.find("UPDATE")!=cmd.npos){
      //UPDATE district SET d_next_o_id = 3577 + 1 WHERE d_id = 5 AND d_w_id = 1"
      //pend-hkc-1
      continue;
    }

  }
  return;

}


void Consumer_CustomerTree(ProAndCon* itemQ_){
  // Schema  
/*
create table customer (
c_id int not null, 16
c_d_id tinyint not null,  16
c_w_id smallint not null, 16

c_first varchar(16),  16
c_middle char(2),   2
c_last varchar(16), 16
c_street_1 varchar(20), 20 
c_street_2 varchar(20),  20
c_city varchar(20), 20
c_state char(2),        2
c_zip char(9),          9
c_phone char(16),       16
c_since datetime,       20
c_credit char(2),       2
c_credit_lim bigint,    16
c_discount decimal(4,2), 6
c_balance decimal(12,2), 14
c_ytd_payment decimal(12,2), 14
c_payment_cnt smallint, 16
c_delivery_cnt smallint, 16
c_data text,  100 // for text >100, simply discard
PRIMARY KEY(c_w_id, c_d_id, c_id) ) Engine=InnoDB
*/

//FROM customer, warehouse WHERE 
//w_id = 1 AND c_w_id = w_id AND c_d_id = 5 AND c_id = 1026


  //std::cout << "+++++++++++++++ TEST Customer Tree BEGIN ++++++++++++++++++++\n";
  std::string CustomerDir = "/media/hkc/csd_3/HTAP_DirTrees/test";
  std::string DB_path = CustomerDir + "Customer/";
  std::string db = DB_path + "testCustomer.db";
  std::string log = DB_path + "testCustomer.log";
  std::string chpt = DB_path + "chptCustomer.log";
  CustomerTree = new BPlusCustomerTree(db.c_str(), log.c_str(), chpt.c_str(), bg_id++, true);
  // load
  CustomerTree->SetBaseline();
  CustomerTree->SetLoadFlag(1);
  char k[48] = {'\0'};
  char v[325] = {'\0'};
  while(1){
    char* cmd_char = itemQ_->consumption();
    std::string cmd(cmd_char, cmd_char + strlen(cmd_char));
    free(cmd_char);
    if(cmd.find("INSERT")!=cmd.npos){
      std::string contents = cmd.substr(cmd.find("(") + 1, cmd.find(")") - 2);
      contents = contents.replace(contents.find(")"), 1, "");
      replace(contents.begin(), contents.end(), '\'', ',');
      std::vector<std::string> res = split(contents, ",");
      int pk1 = atoi(res[2].c_str());
      int pk2 = atoi(res[1].c_str());
      int pk3 = atoi(res[0].c_str());
      snprintf(k, 48, "%16d%16d%16d", pk1,pk2,pk3);
      //snprintf(v, 16 + 20 + 16 + 16 +16, "%16s%20s%16s%16s%16s", i, rand() % 10000000, rand() % 10000000, rand() % 10000, rand() % 100000000,rand()%10000000);
      off_t lsn = CustomerTree->GetLSN();
      snprintf(v, 16+2+16+20+20+20+2+9+16+20+2+16+6+14+14+16+16+100, 
                  "%16s%2s%16s%20s%20s%20s%2s%9s%16s%20s%2s%16s%6s%14s%14s%16s%16s%100s", 
          res[3].c_str(), 
          res[4].c_str(), 
          res[5].c_str(), 
          res[6].c_str(),
          res[7].c_str(),
          res[8].c_str(),
          res[9].c_str(),
          res[10].c_str(),
          res[11].c_str(),
          res[12].c_str(),
          res[13].c_str(),
          res[14].c_str(),
          res[15].c_str(),
          res[16].c_str(),
          res[17].c_str(),
          res[18].c_str(),
          res[19].c_str(),
          res[20].c_str()
          );
      CustomerTree->Put(k, v, lsn);
      CustomerTree->IncreLSN();

    }else if (cmd.find("UPDATE customer")!=cmd.npos){
      //UPDATE customer SET c_balance = c_balance + 195.64999389648438 , c_delivery_cnt = c_delivery_cnt + 1 WHERE c_id = 264 AND c_d_id = 7 AND c_w_id = 1
      continue;  //pend-hkc-3
    }else if (cmd.find("SELECT")!=cmd.npos){
      //case 1
      //FROM customer, warehouse WHERE  w_id = 1 AND c_w_id = w_id AND c_d_id = 5 AND c_id = 1026
      //case 2
      //ELECT count(c_id) FROM customer WHERE c_w_id = 2 AND c_d_id = 6 AND c_last = 'ESEBARBAR'"
      std::string contents_1 = cmd.substr(cmd.find("c_w_id =") + 1, cmd.length());
      std::vector<std::string> res_1 = split(contents_1, " ");
      int pk1 =0;
      if(res_1[2] == "w_id"){
        std::string contents_0 = cmd.substr(cmd.find("w_id =") + 1, cmd.length());
        std::vector<std::string> res_0 = split(contents_0, " ");
        pk1 = atoi(res_0[2].c_str());
      }else{
        pk1 = atoi(res_1[2].c_str());
      }
      
      std::string contents_2 = cmd.substr(cmd.find("c_d_id =") + 1, cmd.length());
      std::vector<std::string> res_2 = split(contents_2, " ");
      int pk2 = atoi(res_2[2].c_str());
      std::string contents_3 = cmd.substr(cmd.find("c_id =") + 1, cmd.length());
      std::vector<std::string> res_3 = split(contents_3, " ");
      int pk3 = atoi(res_3[2].c_str());;
      snprintf(k, 48, "%16d%16d%16d", pk1,pk2,pk3);
      //char k[48] = {'\0'};
      char start[48] = {'\0'};
      char end[48] = {'\0'};
      snprintf(start, 48, "%16d%16d%16d", pk1,pk2,pk3);
      snprintf(end, 48, "%16d%16d%16d", pk1,pk2,pk3+3000);
      std::string value;
      //CustomerTree->Get(k,value);
      CustomerTree->Scan(start,end,value);
      value[0] = value[1];
      
      

    }

    
    // SELECT c_data FROM customer WHERE c_w_id = 2 AND c_d_id = 1 AND c_id = 777
    //SELECT c_first, c_middle, c_last, c_street_1, c_street_2, c_city, c_state, c_zip, c_phone, c_credit, c_credit_lim, c_discount, c_balance, c_since FROM customer WHERE c_w_id = 2 AND c_d_id = 1 AND c_id = 777 FOR UPDATE
  }
  return;

}



void Consumer_Historyfk1Tree(ProAndCon* itemQ_){
  //  create table history (
  //  h_c_id int,
  //  h_c_d_id tinyint,
  //  h_c_w_id smallint,

  //  h_d_id tinyint,
  //  h_w_id smallint,
  //  h_date datetime,
  //  h_amount decimal(6,2),
  //  h_data varchar(24) ) Engine=InnoDB
  //  ADD CONSTRAINT fkey_history_1 FOREIGN KEY(h_c_w_id,h_c_d_id,h_c_id) REFERENCES customer(c_w_id,c_d_id,c_id)
  //	ALTER TABLE history  ADD CONSTRAINT fkey_history_2 FOREIGN KEY(h_w_id,h_d_id) REFERENCES district(d_w_id,d_id)
  //std::cout << "+++++++++++++++ TEST Historyfk1 Tree BEGIN ++++++++++++++++++++\n";
  std::string Historyfk1Dir = "/media/hkc/csd_3/HTAP_DirTrees/test";
  std::string DB_path = Historyfk1Dir + "Historyfk1/";
  std::string db = DB_path + "testHistoryfk1.db";
  std::string log = DB_path + "testHistoryfk1.log";
  std::string chpt = DB_path + "chptHistoryfk1.log";
  Historyfk1Tree = new BPlusHistoryfk1Tree(db.c_str(), log.c_str(), chpt.c_str(), bg_id++, true);
  // load
  Historyfk1Tree->SetBaseline();
  Historyfk1Tree->SetLoadFlag(1);
  char k[48] = {'\0'};
  char v[84] = {'\0'};
  while(1){
    char* cmd_char = itemQ_->consumption();
    std::string cmd(cmd_char, cmd_char + strlen(cmd_char));
    free(cmd_char);
    if(cmd.find("INSERT")!=cmd.npos){
    std::string contents = cmd.substr(cmd.find("(") + 1, cmd.find(")") - 2);
    contents = contents.replace(contents.find(")"), 1, "");
    replace(contents.begin(), contents.end(), '\'', ',');
    std::vector<std::string> res = split(contents, ",");
    int pk1 = atoi(res[2].c_str());
    int pk2 = atoi(res[1].c_str());
    int pk3 = atoi(res[0].c_str());
    snprintf(k, 48, "%16d%16d%16d", pk1,pk2,pk3);
    //snprintf(v, 16 + 20 + 16 + 16 +16, "%16s%20s%16s%16s%16s", i, rand() % 10000000, rand() % 10000000, rand() % 10000, rand() % 100000000,rand()%10000000);
    off_t lsn = Historyfk1Tree->GetLSN();
    snprintf(v, 16+16+20+8+24, "%16s%16s%20s%8s%24s", 
        res[3].c_str(), 
        res[4].c_str(), 
        res[5].c_str(), 
        res[6].c_str(),
        res[7].c_str()
        );
    Historyfk1Tree->Put(k, v, lsn);
    Historyfk1Tree->IncreLSN();
    }else if (cmd.find("UPDATE")!=cmd.npos){
      continue;
    }else if (cmd.find("SELECT")!=cmd.npos){
      continue;
    }
  }
  return;

}


void Consumer_Historyfk2Tree(ProAndCon* itemQ_){
  //  create table history (
  //  h_c_id int,
  //  h_c_d_id tinyint,
  //  h_c_w_id smallint,

  //  h_d_id tinyint,
  //  h_w_id smallint,
  //  h_date datetime,
  //  h_amount decimal(6,2),
  //  h_data varchar(24) ) Engine=InnoDB
  //  ADD CONSTRAINT fkey_history_1 FOREIGN KEY(h_c_w_id,h_c_d_id,h_c_id) REFERENCES customer(c_w_id,c_d_id,c_id)
  //	ALTER TABLE history  ADD CONSTRAINT fkey_history_2 FOREIGN KEY(h_w_id,h_d_id) REFERENCES district(d_w_id,d_id)
  //std::cout << "+++++++++++++++ TEST Historyfk2 Tree BEGIN ++++++++++++++++++++\n";
  std::string Historyfk2Dir = "/media/hkc/csd_3/HTAP_DirTrees/test";
  std::string DB_path = Historyfk2Dir + "Historyfk2/";
  std::string db = DB_path + "testHistoryfk2.db";
  std::string log = DB_path + "testHistoryfk2.log";
  std::string chpt = DB_path + "chptHistoryfk2.log";
  Historyfk2Tree = new BPlusHistoryfk2Tree(db.c_str(), log.c_str(), chpt.c_str(), bg_id++, true);
  // load
  Historyfk2Tree->SetBaseline();
  Historyfk2Tree->SetLoadFlag(1);
  char k[32] = {'\0'};
  char v[16+16+16+20+8+24] = {'\0'};
  while(1){
      char* cmd_char = itemQ_->consumption();
      std::string cmd(cmd_char, cmd_char + strlen(cmd_char));
      free(cmd_char);
    if(cmd.find("INSERT")!=cmd.npos){

      std::string contents = cmd.substr(cmd.find("(") + 1, cmd.find(")") - 2);
      contents = contents.replace(contents.find(")"), 1, "");
      replace(contents.begin(), contents.end(), '\'', ',');
      std::vector<std::string> res = split(contents, ",");
      int pk1 = atoi(res[4].c_str());
      int pk2 = atoi(res[3].c_str());
      snprintf(k, 32, "%16d%16d", pk1,pk2);
      //snprintf(v, 16 + 20 + 16 + 16 +16, "%16s%20s%16s%16s%16s", i, rand() % 10000000, rand() % 10000000, rand() % 10000, rand() % 100000000,rand()%10000000);
      off_t lsn = Historyfk2Tree->GetLSN();
      snprintf(v, 16+16+16+20+8+24, "%16s%16s%16s%20s%8s%24s", 
          res[0].c_str(), 
          res[1].c_str(), 
          res[2].c_str(), 
          res[5].c_str(), 
          res[6].c_str(),
          res[7].c_str()
          );
      Historyfk2Tree->Put(k, v, lsn);
      Historyfk2Tree->IncreLSN();
    }else if (cmd.find("UPDATE")!=cmd.npos){
      continue;
    }else if (cmd.find("SELECT")!=cmd.npos){
      continue;
    }

  }
  return;

}



void Consumer_OrderlineTree(ProAndCon* itemQ_){
    //  create table order_line (
  //  ol_o_id int not null, 16
  //  ol_d_id tinyint not null, 16
  //  ol_w_id smallint not null, 16
  //  ol_number tinyint not null, 16
  
  //  ol_i_id int, 16
  //  ol_supply_w_id smallint, 16
  //  ol_delivery_d datetime, 20
  //  ol_quantity tinyint, 16
  //  ol_amount decimal(6,2), 8
  //  ol_dist_info char(24), 24
  //  PRIMARY KEY(ol_w_id, ol_d_id, ol_o_id, ol_number) ) Engine=InnoDB

  //std::cout << "+++++++++++++++ TEST OrderLine Tree BEGIN ++++++++++++++++++++\n";
  std::string OrderLineDir = "/media/hkc/csd_3/HTAP_DirTrees/test";
  std::string DB_path = OrderLineDir + "OrderLine/";
  std::string db = DB_path + "testOrderLine.db";
  std::string log = DB_path + "testOrderLine.log";
  std::string chpt = DB_path + "chptOrderLine.log";
  OrderLineTree = new BPlusOrderlineTree(db.c_str(), log.c_str(), chpt.c_str(), bg_id++, true);
  // load
  OrderLineTree->SetBaseline();
  OrderLineTree->SetLoadFlag(1);
  char k[64] = {'\0'};
  char v[16 + 16+ 20 + 16 + 8 +24] = {'\0'};
  while(1){
    char* cmd_char = itemQ_->consumption();
    std::string cmd(cmd_char, cmd_char + strlen(cmd_char));
    free(cmd_char);
    if(cmd.find("INSERT")!=cmd.npos){
      std::string contents = cmd.substr(cmd.find("(") + 1, cmd.find(")") - 2);
      contents = contents.replace(contents.find(")"), 1, "");
      replace(contents.begin(), contents.end(), '\'', ',');
      std::vector<std::string> res = split(contents, ",");
      int pk1 = atoi(res[2].c_str());
      int pk2 = atoi(res[1].c_str());
      int pk3 = atoi(res[0].c_str());
      int pk4 = atoi(res[3].c_str());
      snprintf(k, 64, "%16d%16d%16d%16d", pk1,pk2,pk3,pk4);
      //snprintf(v, 16 + 20 + 16 + 16 +16, "%16s%20s%16s%16s%16s", i, rand() % 10000000, rand() % 10000000, rand() % 10000, rand() % 100000000,rand()%10000000);
      off_t lsn = OrderLineTree->GetLSN();
      snprintf(v, 16+16+20+16+8+24, "%16s%16s%20s%16s%8s%24s", 
          res[4].c_str(), 
          res[5].c_str(), 
          res[6].c_str(), 
          res[7].c_str(), 
          res[8].c_str(),
          res[9].c_str()
          );
      OrderLineTree->Put(k, v, lsn);
      OrderLineTree->IncreLSN();
    }else if (cmd.find("SELECT")!=cmd.npos){
      // SELECT ol_i_id, ol_supply_w_id, ol_quantity, ol_amount, ol_delivery_d 
      // FROM order_line WHERE ol_w_id = 2 AND ol_d_id = 6 AND ol_o_id = 2790"
      cmd = cmd.substr(cmd.find("WHERE"),cmd.length());
      std::string contents1 = cmd.substr(cmd.find("ol_w_id"), cmd.length());
      //!!!!scan is pending
      std::vector<std::string> res1 = split(contents1, " ");
      int pk1 = atoi(res1[2].c_str());

      std::string contents2 = cmd.substr(cmd.find("ol_d_id"), cmd.length());
      //!!!!scan is pending
      std::vector<std::string> res2 = split(contents2, " ");
      
      int pk2 = atoi(res2[2].c_str());
      std::string contents3 = cmd.substr(cmd.find("ol_o_id"), cmd.length());
      //!!!!scan is pending
      std::vector<std::string> res3 = split(contents3, " ");
      
      int pk3 = atoi(res3[2].c_str());
      int pk4 = 1; //fake value
      snprintf(k, 64, "%16d%16d%16d%16d", pk1,pk2,pk3,pk4);
      std::string value;
      OrderLineTree->Get(k,value);
      value[0]=value[1];
    }else if (cmd.find("UPDATE")!=cmd.npos){ //pend-hkc-6
      continue; //UPDATE order_line SET ol_delivery_d = '2023-02-26 21:45:32' WHERE ol_o_id = 2667 AND ol_d_id = 1 AND ol_w_id = 1"
    }

  }
  return;

}


void Consumer_NewordersTree(ProAndCon* itemQ_){
//2023-02-26T13:56:03.984105Z	    3 Query	create table new_orders (
//no_o_id int not null,
//no_d_id tinyint not null,
//no_w_id smallint not null,
//PRIMARY KEY(no_w_id, no_d_id, no_o_id)) Engine=InnoDB



  //std::cout << "+++++++++++++++ TEST NewOrders Tree BEGIN ++++++++++++++++++++\n";
  std::string NewOrdersDir = "/media/hkc/csd_3/HTAP_DirTrees/test";
  std::string DB_path = NewOrdersDir + "NewOrders/";
  std::string db = DB_path + "testNewOrders.db";
  std::string log = DB_path + "testNewOrders.log";
  std::string chpt = DB_path + "chptNewOrders.log";
  NewOrdersTree = new BPlusNewOrdersTree(db.c_str(), log.c_str(), chpt.c_str(), bg_id++, true);
  // load
  NewOrdersTree->SetBaseline();
  NewOrdersTree->SetLoadFlag(1);
  char k[48] = {'\0'};
  char v[4] = {'\0'};

  while(1){
    char* cmd_char = itemQ_->consumption();
    std::string cmd(cmd_char, cmd_char + strlen(cmd_char));
    free(cmd_char);
    if(cmd.find("INSERT")!=cmd.npos){
      std::string contents = cmd.substr(cmd.find("(") + 1, cmd.find(")") - 2);
      contents = contents.replace(contents.find(")"), 1, "");
      replace(contents.begin(), contents.end(), '\'', ',');
      std::vector<std::string> res = split(contents, ",");
      int pk1 = atoi(res[2].c_str());
      int pk2 = atoi(res[1].c_str());
      int pk3 = atoi(res[0].c_str());
      snprintf(k, 48, "%16d%16d%16d", pk1,pk2,pk3);
      //snprintf(v, 16 + 20 + 16 + 16 +16, "%16s%20s%16s%16s%16s", i, rand() % 10000000, rand() % 10000000, rand() % 10000, rand() % 100000000,rand()%10000000);
      off_t lsn = NewOrdersTree->GetLSN();
      snprintf(v, 4, "%4s", 
          res[1].c_str()
          );
      NewOrdersTree->Put(k, v, lsn);
      NewOrdersTree->IncreLSN();
    }else if (cmd.find("SELECT")!=cmd.npos){
      //SELECT COALESCE(MIN(no_o_id),0) FROM new_orders WHERE 
      //no_d_id = 1 AND no_w_id = 1"
      std::string contents = cmd.substr(cmd.find("no_d_id") + 1, cmd.length() - 2);
      std::vector<std::string> res = split(contents, " ");
      int pk1 = atoi(res[6].c_str());
      int pk2 = atoi(res[2].c_str());
      int pk3 = 1; //faker one
      //wait for scan!!!!
      snprintf(k, 48, "%16d%16d%16d", pk1,pk2,pk3);
      std::string value;
      NewOrdersTree->Get(k,value);
      value[0]=value[1];
    }else if (cmd.find("UPDATE")!=cmd.npos){
      continue; ////pend-hkc-5
    }

  }
  return;

}



void dispatcher(){
  // it is a procuder to load trace from file and push cmd to different queue
  char *filePath = "/home/hkc/HTAP/PB_HTAP/workloads/TPCC/tpcc_load_2warehouse.log";
  std::ifstream cmd_file;
  cmd_file.open(filePath,std::ios::in);
  if(!cmd_file.is_open()) printf("Error in open trace file");

  ProAndCon* itemQ = new ProAndCon(20);
  std::thread CItemTree = std::thread(Consumer_ItemTree,itemQ);
  CItemTree.detach();

  ProAndCon* stockQ = new ProAndCon(20);
  std::thread CStockTree = std::thread(Consumer_StockTree,stockQ);
  CStockTree.detach();

  ProAndCon* ordersQ = new ProAndCon(20);
  std::thread COrdersTree = std::thread(Consumer_OrdersTree,ordersQ);
  COrdersTree.detach();

  ProAndCon* districtQ = new ProAndCon(20);
  std::thread CDistrictTree = std::thread(Consumer_DistrictTree,districtQ);
  CDistrictTree.detach();

  ProAndCon* historyfk1Q = new ProAndCon(20);
  std::thread CHistoryfk1Tree = std::thread(Consumer_Historyfk1Tree,historyfk1Q);
  CHistoryfk1Tree.detach();

  ProAndCon* historyfk2Q = new ProAndCon(20);
  std::thread CHistoryfk2Tree = std::thread(Consumer_Historyfk2Tree,historyfk2Q);
  CHistoryfk2Tree.detach();

  ProAndCon* orderlineQ = new ProAndCon(20);
  std::thread COrderlineTree = std::thread(Consumer_OrderlineTree,orderlineQ);
  COrderlineTree.detach();

  ProAndCon* newordersQ = new ProAndCon(20);
  std::thread CNewordersTree = std::thread(Consumer_NewordersTree,newordersQ);
  CNewordersTree.detach();

  ProAndCon* customerQ = new ProAndCon(20);
  std::thread CCustomerTree = std::thread(Consumer_CustomerTree,customerQ);
  CCustomerTree.detach();
  
 
  
  std::string cmdLine;
  auto t1 = std::chrono::steady_clock::now();
          
  while(getline(cmd_file,cmdLine))
  {
    // e.g., INSERT INTO order_line values(2999,10,2,9,71869,2, NULL,5,51.959999084472656,'i9gYEDJEafCdkaNYVhLRnj6L')
    if(cmdLine.empty() || cmdLine.find("INSERT INTO") == cmdLine.npos || cmdLine.find("?") != cmdLine.npos){
      continue;
    }else if (cmdLine.find("INSERT INTO item values") != cmdLine.npos || cmdLine.find("UPDATE item")!=cmdLine.npos){
      //INSERT INTO item values(1,2498,'8TA69fNTQqhRD7KLKkV',77.2699966430664,'87LD1FH6AFFbPLl2hCSXsukzC3IxW23eAOqBb7')
      char* cmd = (char*)malloc((cmdLine.length()+1)*sizeof(char));
      strcpy(cmd,cmdLine.c_str());
      itemQ->product(cmd);
    }else if (cmdLine.find("INSERT INTO stock values") != cmdLine.npos || cmdLine.find("UPDATE stock")!=cmdLine.npos){
      char* cmd = (char*)malloc((cmdLine.length()+1)*sizeof(char));
      strcpy(cmd,cmdLine.c_str());
      stockQ->product(cmd);
    }else if (cmdLine.find("INSERT INTO orders values") != cmdLine.npos || cmdLine.find("UPDATE orders")!=cmdLine.npos){
      char* cmd = (char*)malloc((cmdLine.length()+1)*sizeof(char));
      strcpy(cmd,cmdLine.c_str());
      ordersQ->product(cmd);
    }else if (cmdLine.find("INSERT INTO district values") != cmdLine.npos || cmdLine.find("UPDATE district")!=cmdLine.npos){
      char* cmd = (char*)malloc((cmdLine.length()+1)*sizeof(char));
      strcpy(cmd,cmdLine.c_str());
      districtQ->product(cmd);
    }else if (cmdLine.find("INSERT INTO history values") != cmdLine.npos || cmdLine.find("UPDATE history")!=cmdLine.npos){
      char* cmd1 = (char*)malloc((cmdLine.length()+1)*sizeof(char));
      strcpy(cmd1,cmdLine.c_str());
      historyfk1Q->product(cmd1);
      char* cmd2 = (char*)malloc((cmdLine.length()+1)*sizeof(char));
      strcpy(cmd2,cmdLine.c_str());
      historyfk2Q->product(cmd2);
    }else if (cmdLine.find("INSERT INTO order_line values") != cmdLine.npos || cmdLine.find("UPDATE order_line")!=cmdLine.npos){
      char* cmd = (char*)malloc((cmdLine.length()+1)*sizeof(char));
      strcpy(cmd,cmdLine.c_str());
      orderlineQ->product(cmd);
    }else if (cmdLine.find("INSERT INTO new_orders values"|| cmdLine.find("UPDATE new_orders")!=cmdLine.npos) != cmdLine.npos){
      char* cmd = (char*)malloc((cmdLine.length()+1)*sizeof(char));
      strcpy(cmd,cmdLine.c_str());
      newordersQ->product(cmd);
    }else if (cmdLine.find("INSERT INTO customer values") != cmdLine.npos || cmdLine.find("UPDATE customer")!=cmdLine.npos){
      char* cmd = (char*)malloc((cmdLine.length()+1)*sizeof(char));
      strcpy(cmd,cmdLine.c_str());
      customerQ->product(cmd);
    }
  }
  
  cmd_file.close();
  auto t2 = std::chrono::steady_clock::now(); 
  auto tmp = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count()/1000;
  std::cout<<"finish load, exe time: "<<tmp<<"\n";
  //test phase
  char *filePath_test = "/home/hkc/HTAP/PB_HTAP/workloads/TPCC/tpcc_run_10thread.log";
  std::ifstream cmd_file_test;
  cmd_file_test.open(filePath_test,std::ios::in);
  if(!cmd_file_test.is_open()) printf("Error in open test trace file\n");

  auto t3 = std::chrono::steady_clock::now(); 
  while(getline(cmd_file_test,cmdLine))
  {
    if(cmdLine.find("?")!=cmdLine.npos){
      continue;

    }else if (cmdLine.find("Execute	SELECT")!=cmdLine.npos){
      //case for read
      // SELECT i_price, i_name, i_data FROM item WHERE i_id = 53126
      char* cmd = (char*)malloc((cmdLine.length()+1)*sizeof(char));
      strcpy(cmd,cmdLine.c_str());
      if(cmdLine.find("FROM item WHERE")!=cmdLine.npos){
        itemQ->product(cmd);
      }else if(cmdLine.find("FROM customer")!=cmdLine.npos){
        customerQ->product(cmd);
      }else if(cmdLine.find("FROM history WHERE")!=cmdLine.npos){
        //not happen, only for backup

      }else if(cmdLine.find("FROM district WHERE")!=cmdLine.npos){
        districtQ->product(cmd);
      }else if(cmdLine.find("FROM new_orders WHERE")!=cmdLine.npos){
        newordersQ->product(cmd);
      }else if(cmdLine.find("FROM order_line WHERE")!=cmdLine.npos){
        orderlineQ->product(cmd);
      }else if(cmdLine.find("FROM orders WHERE")!=cmdLine.npos){
        ordersQ->product(cmd);
      }else if(cmdLine.find("FROM stock WHERE")!=cmdLine.npos){
        stockQ->product(cmd);
      }
    }else if(cmdLine.find("Execute	INSERT")!=cmdLine.npos || cmdLine.find("Execute	UPDATE")!=cmdLine.npos){
      //case for insert
      if (cmdLine.find("INSERT INTO item values") != cmdLine.npos || cmdLine.find("UPDATE item")!=cmdLine.npos){
        //INSERT INTO item values(1,2498,'8TA69fNTQqhRD7KLKkV',77.2699966430664,'87LD1FH6AFFbPLl2hCSXsukzC3IxW23eAOqBb7')
        char* cmd = (char*)malloc((cmdLine.length()+1)*sizeof(char));
        strcpy(cmd,cmdLine.c_str());
        itemQ->product(cmd);
      }else if (cmdLine.find("INSERT INTO stock values") != cmdLine.npos || cmdLine.find("UPDATE stock")!=cmdLine.npos){
        char* cmd = (char*)malloc((cmdLine.length()+1)*sizeof(char));
        strcpy(cmd,cmdLine.c_str());
        stockQ->product(cmd);
      }else if (cmdLine.find("INSERT INTO orders values") != cmdLine.npos || cmdLine.find("UPDATE orders")!=cmdLine.npos){
        char* cmd = (char*)malloc((cmdLine.length()+1)*sizeof(char));
        strcpy(cmd,cmdLine.c_str());
        ordersQ->product(cmd);
      }else if (cmdLine.find("INSERT INTO district values") != cmdLine.npos || cmdLine.find("UPDATE district")!=cmdLine.npos){
        char* cmd = (char*)malloc((cmdLine.length()+1)*sizeof(char));
        strcpy(cmd,cmdLine.c_str());
        districtQ->product(cmd);
      }else if (cmdLine.find("INSERT INTO history values") != cmdLine.npos || cmdLine.find("UPDATE history")!=cmdLine.npos){
        char* cmd1 = (char*)malloc((cmdLine.length()+1)*sizeof(char));
        strcpy(cmd1,cmdLine.c_str());
        historyfk1Q->product(cmd1);
        char* cmd2 = (char*)malloc((cmdLine.length()+1)*sizeof(char));
        strcpy(cmd2,cmdLine.c_str());
        historyfk2Q->product(cmd2);
      }else if (cmdLine.find("INSERT INTO order_line values") != cmdLine.npos || cmdLine.find("UPDATE order_line")!=cmdLine.npos){
        char* cmd = (char*)malloc((cmdLine.length()+1)*sizeof(char));
        strcpy(cmd,cmdLine.c_str());
        orderlineQ->product(cmd);
      }else if (cmdLine.find("INSERT INTO new_orders values"|| cmdLine.find("UPDATE new_orders")!=cmdLine.npos) != cmdLine.npos){
        char* cmd = (char*)malloc((cmdLine.length()+1)*sizeof(char));
        strcpy(cmd,cmdLine.c_str());
        newordersQ->product(cmd);
      }else if (cmdLine.find("INSERT INTO customer values") != cmdLine.npos || cmdLine.find("UPDATE customer")!=cmdLine.npos){
        char* cmd = (char*)malloc((cmdLine.length()+1)*sizeof(char));
        strcpy(cmd,cmdLine.c_str());
        customerQ->product(cmd);
      }

    }
  }
  cmd_file_test.close();
  auto t4 = std::chrono::steady_clock::now(); 
  auto tmp1 = std::chrono::duration_cast<std::chrono::microseconds>(t4 - t3).count()/1000;
  std::cout<<"finish test, exe time: "<<tmp1<<"\n";
  
  
  return ;

}



//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// main
int main(int argc, char const *argv[])
{
  (void)argc;
  (void)argv;

  //TEST_InitLoadItemTree();
  //TEST_InitLoadStockTree();
  //TEST_InitLoadOrdersTree();
  //TEST_InitLoadOrderlineTree();
  //TEST_InitLoadCustomerTree();
  //TEST_InitLoadHistoryfk2_Tree();
  //TEST_InitLoadNewOrdersTree();
  //TEST_InitLoadDistrictTree();
  // HT_InitTrees();
  //TEST_ALL();
  dispatcher();
  return 1;

  // int client_id = atoi(argv[1]);
  int test_plog = 1;
  int clients = 16;

  int load_items = 30000000;
  int test_items = 10000000;
  int scale_items = 20000000;

  // int load_items  = 15000000;
  // int test_items  = 5000000;
  // int scale_items = 5000000;

  /*
  int load_items  = 3000000;
  int test_items  =  3000000;
  int scale_items = 3000000;

  if(test_plog == 1){
    srand(time(0));
    bool enable_plog =true;
    //int client_id=16;
    std::deque<BPlusTree*> Trees;
    std::thread BackGround[clients];
    std::string Dir="/media/hkc/csd_3/DirTrees/test";
    for(int i=0;i<clients;i++){
      std::string DB_path = Dir+std::to_string(i);
      DB_path+="/";
      std::string db = DB_path+"test.db";
      std::string log = DB_path+"test.log";
      std::string chpt = DB_path+"chpt.log";
      BackGround[i]=std::thread(TestPlog,new BPlusTree(db.c_str(), log.c_str(),chpt.c_str(),i,enable_plog),load_items,test_items,scale_items,i);
      BackGround[i].detach();
    }
  }else{
    srand(time(0));
    bool enable_plog =false;
    std::deque<BPlusTree*> Trees;
    std::thread BackGround[clients];
    std::string Dir="/media/hkc/csd_3/DirTrees/test";
    for(int i=0;i<clients;i++){
      std::string DB_path = Dir+std::to_string(i);
      DB_path+="/";
      std::string db = DB_path+"test.db";
      std::string log = DB_path+"test.log";
      std::string chpt = DB_path+"chpt.log";
      BackGround[i]=std::thread(TestBaseline,new BPlusTree(db.c_str(), log.c_str(),chpt.c_str(),i,enable_plog),load_items,test_items,scale_items,i);
      BackGround[i].detach();
    }
  }

   */

  /*Background aio*/

  // std::thread BackGround;

  // BackGround=std::thread(BackGroundManager);
  // BackGround.join();
  // BackGround.detach();

  /*
  //TestBaseline(bpt,load_items,test_items,scale_items);
  //TestPlog(bpt,load_items,test_items,scale_items);
  auto t1 = std::chrono::steady_clock::now();
  std::mutex mu;
  int test_cnt=0;
  while(true){
    int total_malloc =0;
    for(int i=0;i<32;i++){
      if(afterLoad[i]==1){
        auto t2 = std::chrono::steady_clock::now(); //auto t1 = std::chrono::steady_clock::now();
        auto tmp = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count()/1000;
        std::cout<<"Btree-"<<i<<" Load Done, time used: "<<tmp<<" \n";
        mu.lock();
        afterLoad[i]=2;
        mu.unlock();
      }
      if(aftertest[i]==1){
        auto t2 = std::chrono::steady_clock::now();
        auto tmp = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count()/1000;
        std::cout<<"Btree-"<<i<<" TEST Done, time used: "<<tmp<<" \n";
        mu.lock();
        aftertest[i]=2;
        test_cnt++;
        mu.unlock();
      for (int j=0;j<50;j++){
        if(testphase[i][j] == 1){
          auto t2 = std::chrono::steady_clock::now();
          auto tmp = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count()/1000;
          std::cout<<"Btree-"<<i<<" cycle-"<<j<<" Done, time used: "<<tmp<<" \n";
          mu.lock();
          testphase[i][j]=2;
          mu.unlock();
        }
      }
      }
      sleep(10);
      //if(test_cnt >= test_cnt) break;
    }
  }
  */
  return 0;
}